const CONSTANT = {
    HOST:"https://chat1.fluidcast.net/",
    SOCKET:"https://chat1.fluidcast.net",
}