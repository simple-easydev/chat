const CONSTANT = {
    HOST:"http://localhost:8081",
    SOCKET:"https://chat1.camscartel.com",
}